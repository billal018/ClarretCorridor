public class LegacyPayment {
    public void ProcessData(String paymentData){

    }

}
