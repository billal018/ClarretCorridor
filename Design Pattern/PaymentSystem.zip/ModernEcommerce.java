public interface ModernEcommerce {
        void InitialTransaction(String transaction);
        void ProcessTransaction(String transaction);  
} 
    

